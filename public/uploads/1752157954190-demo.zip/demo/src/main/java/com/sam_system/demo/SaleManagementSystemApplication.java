package com.sam_system.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaleManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaleManagementSystemApplication.class, args);
	}

}
