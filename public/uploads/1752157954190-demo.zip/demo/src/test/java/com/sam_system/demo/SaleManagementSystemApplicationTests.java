package com.sam_system.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaleManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
